﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BigSummerFestivalProjScreens
{
	/// <summary>
	/// Interaction logic for Mobile_Template.xaml
	/// </summary>
	public partial class Mobile_Template : UserControl
	{
		public Mobile_Template()
		{
			this.InitializeComponent();
		}
	}
}