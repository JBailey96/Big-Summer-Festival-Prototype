﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BigSummerFestivalProjScreens
{
	/// <summary>
	/// Interaction logic for T_and_C.xaml
	/// </summary>
	public partial class T_and_C : UserControl
	{
		public T_and_C()
		{
			this.InitializeComponent();
		}
	}
}